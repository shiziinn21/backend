from django.contrib import admin
from django.urls import path, include
from . import views


urlpatterns = [
    path('', views.home , name='home'),
    path('produtos/', views.produtos , name='produtos'),
    path('servicos/', views.servicos , name='servicos'),
    path('perfil/', views.perfil , name='perfil'),
    path('carrinho/', views.carrinho, name='carrinho'),
    path('editar_perfil/', views.editar_perfil, name='editar_perfil'),
    path('cadastrar/', views.cadastrar, name='cadastrar'),
    path('admin/', views.admin, name='admin')

]