from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.forms import AuthenticationForm
from .forms import CadastroForm, EditarPerfilForm
from django.contrib.auth.decorators import login_required

# Pasta 'cadastrar'
def cadastrar(request):
    if request.method == 'POST':
        form = CadastroForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect('index')
    else:
        form = CadastroForm()
    return render(request, 'cadastrar/index.html', {'form': form})

# Pasta 'editar_perfil'
@login_required
def editar_perfil(request):
    if request.method == 'POST':
        form = EditarPerfilForm(request.POST, instance=request.user)
        if form.is_valid():
            form.save()
            return redirect('perfil')
    else:
        form = EditarPerfilForm(instance=request.user)
    return render(request, 'editar_perfil/index.html', {'form': form})

# Pasta 'index'
def index(request):
    return render(request, 'index/index.html')

# Pasta 'login'
def login_view(request):
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None:
                login(request, user)
                return redirect('index')
    else:
        form = AuthenticationForm()
    return render(request, 'login/index.html', {'form': form})

# Pasta 'perfil'
@login_required
def perfil(request):
    return render(request, 'perfil/index.html')

def logout_view(request):
    logout(request)
    return redirect('index')